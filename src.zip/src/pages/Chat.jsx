import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { auth, db } from "../config/firebase";
import { doc, getDoc } from "firebase/firestore";
import {
  sendMessage,
  listenToMessages,
  deleteMessage,
  markMessageAsRead
} from "../services/chatService";
import { uploadChatImage } from "../services/storageService";
import toast from "react-hot-toast";
import { FiArrowLeft, FiImage, FiSend, FiTrash2 } from "react-icons/fi";
import "../styles/chat.css";

function Chat() {
  const { chatId } = useParams();
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [otherUser, setOtherUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  // Get chat participant
  useEffect(() => {
    const fetchChatDetails = async () => {
      try {
        const chatRef = doc(db, "chats", chatId);
        const chatDoc = await getDoc(chatRef);

        if (!chatDoc.exists()) {
          toast.error("Chat not found");
          navigate("/");
          return;
        }

        const participants = chatDoc.data().participants;
        const otherUserId = participants.find(id => id !== auth.currentUser.uid);

        if (!otherUserId) {
          toast.error("Invalid chat");
          navigate("/");
          return;
        }

        const userRef = doc(db, "users", otherUserId);
        const userDoc = await getDoc(userRef);

        if (userDoc.exists()) {
          setOtherUser({ uid: otherUserId, ...userDoc.data() });
        }

        setLoading(false);
      } catch (error) {
        toast.error("Failed to load chat");
        navigate("/");
      }
    };

    fetchChatDetails();
  }, [chatId, navigate]);

  // Listen to messages
  useEffect(() => {
    if (!chatId) return;

    const unsubscribe = listenToMessages(chatId, (loadedMessages) => {
      setMessages(loadedMessages);
      
      // Mark messages as read
      loadedMessages.forEach(msg => {
        if (msg.senderId !== auth.currentUser.uid) {
          markMessageAsRead(chatId, msg.id, auth.currentUser.uid);
        }
      });
    });

    return () => unsubscribe?.();
  }, [chatId]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() && inputValue.trim().length === 0) return;

    try {
      setSending(true);
      await sendMessage(chatId, auth.currentUser.uid, {
        type: "text",
        text: inputValue
      });
      setInputValue("");
    } catch (error) {
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setSending(true);
      const mediaURL = await uploadChatImage(chatId, auth.currentUser.uid, file);
      await sendMessage(chatId, auth.currentUser.uid, {
        type: "image",
        mediaURL
      });
      fileInputRef.current.value = "";
    } catch (error) {
      toast.error("Failed to upload image");
    } finally {
      setSending(false);
    }
  };

  const handleDeleteMessage = async (messageId) => {
    try {
      await deleteMessage(chatId, messageId);
      toast.success("Message deleted");
    } catch (error) {
      toast.error("Failed to delete message");
    }
  };

  if (loading) {
    return <div className="chat-loading">Loading chat...</div>;
  }

  return (
    <div className="chat-container">
      {/* Header */}
      <div className="chat-header">
        <button onClick={() => navigate("/")} className="back-btn">
          <FiArrowLeft size={20} />
        </button>
        <div className="chat-user-info">
          <img
            src={otherUser?.photoURL || "https://via.placeholder.com/40"}
            alt={otherUser?.displayName}
          />
          <div>
            <p className="chat-user-name">{otherUser?.displayName}</p>
            <p className="chat-user-handle">@{otherUser?.username}</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="no-messages">
            <p>Start a conversation with {otherUser?.displayName}</p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`message ${
                msg.senderId === auth.currentUser.uid ? "sent" : "received"
              }`}
            >
              {msg.type === "text" ? (
                <p className="message-text">{msg.text}</p>
              ) : (
                <img src={msg.mediaURL} alt="Message" className="message-image" />
              )}
              <span className="message-time">
                {msg.timestamp?.toDate?.().toLocaleTimeString?.() || ""}
              </span>
              {msg.senderId === auth.currentUser.uid && (
                <button
                  onClick={() => handleDeleteMessage(msg.id)}
                  className="delete-btn"
                >
                  <FiTrash2 size={14} />
                </button>
              )}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="message-input-container">
        <button
          onClick={() => fileInputRef.current?.click()}
          className="image-btn"
          disabled={sending}
        >
          <FiImage size={20} />
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageUpload}
          accept="image/*"
          hidden
        />
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          placeholder="Type a message..."
          className="message-input"
          disabled={sending}
        />
        <button
          onClick={handleSendMessage}
          className="send-btn"
          disabled={sending || !inputValue.trim()}
        >
          <FiSend size={20} />
        </button>
      </div>
    </div>
  );
}

export default Chat;