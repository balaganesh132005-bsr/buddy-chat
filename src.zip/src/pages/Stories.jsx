import React, { useState, useEffect, useRef } from "react";
import { auth } from "../config/firebase";
import { getActiveStories, createStory, viewStory } from "../services/storyService";
import { uploadStoryMedia } from "../services/storageService";
import toast from "react-hot-toast";
import { FiPlus, FiX, FiEye } from "react-icons/fi";
import "../styles/stories.css";

function Stories() {
  const [stories, setStories] = useState([]);
  const [showUpload, setShowUpload] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    loadStories();
  }, []);

  const loadStories = async () => {
    try {
      const activeStories = await getActiveStories();
      setStories(activeStories);
    } catch (error) {
      toast.error("Failed to load stories");
    }
  };

  const handleStoryUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const mediaURL = await uploadStoryMedia(auth.currentUser.uid, file, "photo");
      await createStory(auth.currentUser.uid, {
        mediaURL,
        mediaType: "photo"
      });
      toast.success("Story posted!");
      setShowUpload(false);
      loadStories();
      fileInputRef.current.value = "";
    } catch (error) {
      toast.error("Failed to upload story");
    } finally {
      setUploading(false);
    }
  };

  const handleViewStory = async (storyId) => {
    try {
      await viewStory(storyId, auth.currentUser.uid);
      loadStories();
    } catch (error) {
      console.error("Error viewing story:", error);
    }
  };

  return (
    <div className="stories-container">
      <div className="stories-header">
        <h2>Stories</h2>
        <button
          onClick={() => setShowUpload(!showUpload)}
          className="upload-story-btn"
        >
          <FiPlus size={20} /> Add Story
        </button>
      </div>

      {showUpload && (
        <div className="upload-section">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleStoryUpload}
            accept="image/*"
            disabled={uploading}
          />
          <button
            onClick={() => setShowUpload(false)}
            className="close-upload"
          >
            <FiX size={20} />
          </button>
        </div>
      )}

      <div className="stories-grid">
        {stories.length === 0 ? (
          <p className="no-stories">No stories yet</p>
        ) : (
          stories.map((story) => (
            <div
              key={story.id}
              className="story-card"
              onClick={() => handleViewStory(story.id)}
            >
              <img src={story.mediaURL} alt="Story" />
              <div className="story-overlay">
                <img
                  src={story.owner.photoURL || "https://via.placeholder.com/30"}
                  alt={story.owner.username}
                  className="story-avatar"
                />
                <p className="story-name">@{story.owner.username}</p>
                <div className="story-views">
                  <FiEye size={14} /> {story.viewCount}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Stories;